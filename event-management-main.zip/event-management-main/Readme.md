# Event-Management

## [ Private Repo Link](https://classroom.github.com/a/ehOGNGkI)

Click here for the private repo: [https://classroom.github.com/a/ehOGNGkI](https://classroom.github.com/a/ehOGNGkI)
